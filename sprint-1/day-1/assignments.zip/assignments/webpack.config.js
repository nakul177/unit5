const path = require('path');

module.exports = {
  entry: './src/index.js',
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: 'bundle.js',
  },module: {
    rules: [
      { test: /\.css$/, use: [  {
        loader: 'style-loader',
        loader: 'css-loader'
      } ]},
     
    ],
  }, module: {
    rules: [
      {
        test: /\.(png|jpe?g|gif)$/i,
        use: [
          {
            loader: 'file-loader',
          },
        ],
      },
    ],
  }
  ,  
};