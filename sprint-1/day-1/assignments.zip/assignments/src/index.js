

// import"./index.css"
import logo from "./logo/joker.jpg"

const img = document.createElement("img")
img.src = logo
img.setAttribute("id", "logo")

document.getElementById("input").append(img)
addEventListener("click" , done)

function done(){
    const blog = document.getElementById("note").value
    const body = document.getElementById("body")
    body.append(blog)
}